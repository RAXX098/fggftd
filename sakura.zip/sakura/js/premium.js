const chalk = require('chalk')
const fs = require('fs')
global.premiums = `Feature Khusus Premium\nMau premium? chat wa.me/6282280420522` //ini untuk wm stiker ya kawan
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})